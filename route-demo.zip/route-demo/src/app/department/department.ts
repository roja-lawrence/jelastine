export interface IDepartment
{
    deptid : string;
    deptname : string;
    deptstr : number;
}