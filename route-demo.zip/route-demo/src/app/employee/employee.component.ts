import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employees : IEmployee[] =[{
    eid : 101,
    ename : 'Taylor swift',
    esal : 50000,
  },
  { eid : 102,
    ename : 'Katty peri',
    esal : 55000},
    { eid : 103,
      ename : 'Eli goudling',
      esal : 60000},
      { eid : 104,
        ename : 'Ed sheerin',
        esal : 65000}

];

  constructor() { }

  ngOnInit() {
  }
delete(emp : IEmployee)
{
  let arr =this.employees.filter(p=> p.eid!=emp.eid);
  this.employees=arr;
}
}
