package Clients;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Customer.MoneyTran;

public class Clients {
	public static Connection connect() throws ClassNotFoundException, SQLException
	{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","India123");
			return con;	

	}
	public static List<MoneyTran>li=new ArrayList<MoneyTran>();
	public static List<MoneyTran> getTxList()
	{
	return li;
	}
	public static void setTxList(List<MoneyTran>li)
	{
		Clients.li=li;
	}
}
