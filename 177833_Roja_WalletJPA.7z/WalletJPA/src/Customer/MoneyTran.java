package Customer;

import java.time.LocalDateTime;

public class MoneyTran {
	private String name;
	private double amount;
	private double balance;
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	private LocalDateTime date;
	private int id;
	
	public MoneyTran() {
		super();// TODO Auto-generated constructor stub
	}
	public MoneyTran(String name, double amount,double balance,LocalDateTime date,int id)
	{
		this.date=date;
		this.name=name;
		this.amount=amount;
		this.balance=balance;
		this.id=id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getAmount() {
		return amount;
	}
	public void setMoney(double amount) {
		this.amount = amount;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "MoneyTran [operation=" + name + ", amount=" + amount + ",balance="+balance+",date=" + date + ",]";
	}
	
	}

