package service;

import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;


import Customer.Customers;
import Customer.MoneyTran;
import WalletException.WaExceptions;
import dao.Bank_Dao;

public class Bank_Service implements Bank_Service_Interface {
		Bank_Dao d=new Bank_Dao();
		public void validateName(String name) throws WaExceptions {
			String nameRegEx = "[A-Z]{1}[a-zA-Z ]+";
			if (!Pattern.matches(nameRegEx, name)) {
				throw new WaExceptions("first letter should be capital ");
			}
		}

		public void validateAddress(String address) throws WaExceptions {
			String addressRegEx = "[a-zA-Z ]+";
			if (!Pattern.matches(addressRegEx, address)) {
				throw new WaExceptions("address should be alphabets only");
			}
			
		}

		public void validatePhone(String phone) throws WaExceptions {
			String phoneRegEx = "[7-9]{1}[0-9]{9}";
			if (!Pattern.matches(phoneRegEx,phone)) {
				throw new WaExceptions("enter valid number");
			}
			
		}

		public void validateAccount(String account) throws WaExceptions {
			String accountRegEx = "[0-9]{10}";
			if (!Pattern.matches(accountRegEx,account)) {
				throw new WaExceptions("enter valid number");
			}
			
		}
//add customer
		public void addCustomer(Customers c) throws SQLException, ClassNotFoundException, WaExceptions {
			d.addCustomer(c);
			
		
		}
		
//show balance
		public Customers searchId(int id1) throws WaExceptions, ClassNotFoundException, SQLException {
		
			Customers a=d.searchId(id1);
			return a;
		}
//deposite amount
		public void searchId(int id2, double total) throws Exception {
			d.searchId(id2,total);
		
		}
//withdraw
		public void searchwithdrawId(int id3, double wamount) throws Exception {
		
		 d.searchwithdrawId(id3,wamount);
		}
//FUND TRANSFER
		public void searchfundId(int id4, double famount) throws WaExceptions, ClassNotFoundException, SQLException {
			
			 d.searchfundId(id4,famount);
		}
//GET DETAILS
		public Customers searchId1(int id8) throws WaExceptions, ClassNotFoundException, SQLException {
			
			Customers a=d.searchId(id8);
			return a;
		}

		public List<MoneyTran> getTransaction()throws WaExceptions {
			// TODO Auto-generated method stub
			return d.getTransaction();
		}

	
}

		
	


