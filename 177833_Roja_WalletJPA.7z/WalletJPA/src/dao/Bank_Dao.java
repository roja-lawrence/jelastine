package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Clients.Clients;
import Customer.Customers;
import Customer.MoneyTran;
import WalletException.WaExceptions;

public class Bank_Dao implements Bank_Dao_Interface {
	Customers c1;
	//Customers c1=new Customers();
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("WalletJPA");
	EntityManager em = factory.createEntityManager();
	
//add customer
public void addCustomer(Customers c) throws WaExceptions, SQLException, ClassNotFoundException {
		
	/*factory.getTransaction().begin();
	factory.persist(c);
	factory.getTransaction().commit();*/
	em.getTransaction().begin();
	em.persist(c);
	
	em.getTransaction().commit();
	
	
	
}

//get balance
	public Customers searchId(int id1) throws WaExceptions, SQLException,ClassNotFoundException {
	
		if(em.find(Customers.class, id1)!=null)
		{
			
			c1=em.find(Customers.class, id1);
			//System.out.println(c1.getBalance());
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		return c1;
		
	}
//deposite money
	public void searchId(int id2, double total) throws Exception{
		em.getTransaction().begin();
		if(em.find(Customers.class, id2)!=null)
		{
			em.find(Customers.class, id2);
			
			c1.setBalance(total);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		em.getTransaction().commit();
		
		
		
}
//withdraw amount
	public void searchwithdrawId(int id3, double wamount) throws Exception{
		em.getTransaction().begin();
		if(em.find(Customers.class, id3)!=null)
		{
			em.find(Customers.class, id3);
			
			c1.setBalance(wamount);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		em.getTransaction().commit();
	}

	
	
//fund transfer
	public void searchfundId(int id4, double famount) throws WaExceptions, SQLException, ClassNotFoundException{
		em.getTransaction().begin();
		if(em.find(Customers.class, id4)!=null)
		{
			em.find(Customers.class, id4);
			
			c1.setBalance(famount);
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		em.getTransaction().commit();
		
	}
	public Customers searchId1(int id8) throws WaExceptions, SQLException,ClassNotFoundException {
		
		if(em.find(Customers.class, id8)!=null)
		{
			
			c1=em.find(Customers.class, id8);
			//System.out.println(c1.getBalance());
		}
		else {
			System.out.println("Use does't exist.");
		}
		
		
		
		return c1;

}

	public List<MoneyTran> getTransaction()throws WaExceptions {
		// TODO Auto-generated method stub
		return Clients.li;
	}
	
}
