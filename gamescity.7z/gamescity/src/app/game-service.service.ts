import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Igame } from './play/Igame';


@Injectable({
  providedIn: 'root'
})
export class GameServiceService {
  gameproduct:Igame[];
url:string="assets/gamelist.json"
  constructor(private http:HttpClient) { }

  getgame():any{
    this.http.get<Igame[]>(this.url).subscribe(give=>{
    this.gameproduct=give;

    })
  }
}
