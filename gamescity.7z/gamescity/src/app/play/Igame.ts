export class Igame{
Gamename:string;
Gamerupees:number;
}