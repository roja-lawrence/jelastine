import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { GameServiceService } from '../game-service.service';
import { Router, RouterLink } from '@angular/router';
import { SuccessComponent } from '../success/success.component';
import {Route,RouterModule } from '@angular/router';


@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {
  constantvalue:number=600;
  

 



  constructor(private service:GameServiceService, private Route:Router) { }
  lowPrice:boolean = false;
  @Output() messageEvent = new EventEmitter<number>();
  ngOnInit() {
    this.service.getgame();
    this.messageEvent.emit( this.constantvalue);
  }
  buy(b){
    if(b.Gamerupees<=this.constantvalue){
      this.constantvalue=this.constantvalue-b.Gamerupees;
      
      
      this.lowPrice = false;
      this.messageEvent.emit(this.constantvalue);
      this.Route.navigate(['/success']);
      
    }
    else{
    this.lowPrice = true;
  }
    }


}
