package com.cg.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},
features = {"C:\\Users\\nkathirv\\Desktop\\Mod 1\\Exercise\\MovieTicketBooking\\Features\\Booking.feature"},
glue = {"com.cg.BookingStepDefinition"},
dryRun = false)
public class BookingTestRunner {

}
