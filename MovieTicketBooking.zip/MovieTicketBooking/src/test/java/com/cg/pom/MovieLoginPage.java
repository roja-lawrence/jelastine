package com.cg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class MovieLoginPage {
WebDriver driver;
	
	@FindBy(how=How.NAME, using ="userName" )
	@CacheLookup
	private WebElement username;

	@FindBy(how=How.NAME, using="userPwd" )
	@CacheLookup
	private WebElement password;

	@FindBy(how=How.XPATH, using="//*[@id=\"mainCnt\"]/center/div/div/form/table/tbody/tr[4]/td[2]/input" )
	@CacheLookup
	private WebElement login;

	@FindBy(how=How.XPATH, using="//*[@id=\"mainCnt\"]/center/div/div/h1" )
	@CacheLookup
	private WebElement heading;
	
	@FindBy(how=How.ID, using="userErrMsg" )
	@CacheLookup
	private WebElement usererrmsg;
	
	@FindBy(how=How.ID, using="pwdErrMsg" )
	@CacheLookup
	private WebElement pwderrmsg;
	
	public MovieLoginPage() {
		super();
	}

	public MovieLoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public String getHeading() {
		return this.heading.getText();
	}

	public String getUserErrMsg() {
		return this.usererrmsg.getText();
	}
	
	public String getPwdErrMsg() {
		return this.pwderrmsg.getText();
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void setLogin() {
		this.login.click();
	}

}
