package com.cg.Service;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;
import com.cg.DAO.BankDAOImpl;
import com.cg.Util.BankUtil;

public class BankServiceImpl implements BankService {
	BankDAOImpl db = new BankDAOImpl();

	public void storeIntoAccountDatabase(Account account) {
		db.storeIntoAccountDatabase(account);
	}

	public Account getFromAccountDatabase(int accountNumber) {
		return db.getFromAccountDatabase(accountNumber);
	}

	public void storeIntoWalletDatabase(Wallet wallet) {
		db.storeIntoWalletDatabase(wallet);
	}

	public Wallet getFromWalletDatabase(int walletID) {
		return db.getFromWalletDatabase(walletID);
	}

	public void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions) {
		db.storeIntoTransactionsDatabase(accountNumber, transactions);
	}

	public Transactions getFromTransactionsDatabase(int accountNumber) {
		return db.getFromTransactionsDatabase(accountNumber);
	}

	public void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions) {
		db.storeIntoWalletTransactionsDatabase(walletID, walletTransactions);
	}

	public WalletTransactions getFromWalletTransactionsDatabase(int walletID) {
		return db.getFromWalletTransactionsDatabase(walletID);
	}

	public int getAccountCount() {
		return db.getAccountCount();
	}

	// Print all data from map
	public void getTransactionFromWalletDatabase() {
		db.getTransactionFromWalletDatabase();
	}

	// Print all data from map
	public void getTransactionFromAccountDatabase() {
		db.getTransactionFromAccountDatabase();
	}

	public void addToTransactionList(String transaction) {
		db.addToTransactionList(transaction);
	}

	public void addToWalletTransactionList(String transaction) {
		db.addToWalletTransactionList(transaction);
	}

	public boolean checkCredentials(int userName, String passWord) {
		if (BankUtil.getAccountDatabase().containsKey(userName)) {
			Account credentials = BankUtil.getAccountDatabase().get(userName);
			if (credentials.getMobileNumber().equals(passWord))
				return true;
			else
				return false;
		} else
			return false;
	}
}
