package com.cg.DAO;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;
import com.cg.Util.BankUtil;

public class BankDAOImpl implements BankDAO {
	public void storeIntoAccountDatabase(Account account) {
		BankUtil.storeIntoAccountDatabase(account);
	}

	public Account getFromAccountDatabase(int accountNumber) {
		return BankUtil.getFromAccountDatabase(accountNumber);
	}

	public void storeIntoWalletDatabase(Wallet wallet) {
		BankUtil.storeIntoWalletDatabase(wallet);
	}

	public Wallet getFromWalletDatabase(int walletID) {
		return BankUtil.getFromWalletDatabase(walletID);
	}

	public void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions) {
		BankUtil.storeIntoTransactionsDatabase(accountNumber, transactions);
	}

	public Transactions getFromTransactionsDatabase(int accountNumber) {
		return BankUtil.getFromTransactionsDatabase(accountNumber);
	}

	public void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions) {
		BankUtil.storeIntoWalletTransactionsDatabase(walletID, walletTransactions);
	}

	public WalletTransactions getFromWalletTransactionsDatabase(int walletID) {
		return BankUtil.getFromWalletTransactionsDatabase(walletID);
	}

	public int getAccountCount() {
		return BankUtil.getAccountCount();
	}

	// Print all data from map
	public void getTransactionFromWalletDatabase() {
		BankUtil.getTransactionFromWalletDatabase();
	}

	// Print all data from map
	public void getTransactionFromAccountDatabase() {
		BankUtil.getTransactionFromAccountDatabase();
	}

	public void addToTransactionList(String transaction) {
		BankUtil.addToTransactionList(transaction);
	}

	public void addToWalletTransactionList(String transaction) {
		BankUtil.addToWalletTransactionList(transaction);
	}
}
