package com.cg.DAO;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;

public interface BankDAO {
	public void storeIntoAccountDatabase(Account account);

	public Account getFromAccountDatabase(int accountNumber);

	public void storeIntoWalletDatabase(Wallet wallet);

	public Wallet getFromWalletDatabase(int walletID);

	public void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions);

	public Transactions getFromTransactionsDatabase(int accountNumber);

	public void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions);

	public WalletTransactions getFromWalletTransactionsDatabase(int walletID);

	public int getAccountCount();

	public void getTransactionFromWalletDatabase();

	public void getTransactionFromAccountDatabase();
}
