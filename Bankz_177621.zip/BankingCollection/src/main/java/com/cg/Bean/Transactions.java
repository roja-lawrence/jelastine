package com.cg.Bean;

import java.util.ArrayList;
import java.util.List;

public class Transactions {
	List<String> transactList = new ArrayList<String>();

	public List<String> getTransactList() {
		return transactList;
	}

	public void setTransactList(List<String> transactList) {
		this.transactList = transactList;
	}

	public void addToTransactionList(String transaction) {
		transactList.add(transaction);
	}

	@Override
	public String toString() {
		for (String transactions : transactList)
			return transactions;
		return null;
	}
}
