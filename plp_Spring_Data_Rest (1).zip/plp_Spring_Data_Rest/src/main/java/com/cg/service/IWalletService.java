package com.cg.service;

import java.util.List;

import com.cg.beans.Customer;
import com.cg.beans.Transaction;

public interface IWalletService {
	public Customer createAccount(Customer customer) ;

	public double showBalance(int customerId);

	public boolean deposit(int customerId, double amount);

	public boolean withdraw(int customerId, double amount) ;

	public boolean fundTransfer(int customerId, int customId, double amount) ;

	List<Transaction> printTransaction(int customerId) ;

	public Customer validateId(int customerId);

}
