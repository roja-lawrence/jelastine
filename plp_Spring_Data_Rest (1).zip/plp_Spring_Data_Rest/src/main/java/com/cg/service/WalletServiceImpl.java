package com.cg.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Account;
import com.cg.beans.Customer;
import com.cg.beans.Transaction;
import com.cg.dao.CustomerRepository;
import com.cg.exception.WalletException;
@Service
public class WalletServiceImpl implements IWalletService {
	@Autowired
	CustomerRepository customerRepository;
    @Autowired
    Account account;
    @Autowired
    Transaction transaction;
    @Autowired
    List<Transaction> transactionList;
	@Autowired
	Customer customer;
	public Customer createAccount(Customer customer) {
		
		Account newAccount= new Account();
		newAccount.setBalance(0.0);
		customer.setAccount(newAccount);
		//transactionList.add(transaction);
		//customer.setTransactionList(transactionList);
		return customerRepository.save(customer);
	}

	public double showBalance(int customerId)  {
	
		return customerRepository.findById(customerId).get().getAccount().getBalance();
	    
	}

	public boolean deposit(int customerId, double amount) {
		
		customer = customerRepository.findById(customerId).get();
		double balance = customer.getAccount().getBalance() + amount;
		account = customer.getAccount();
		account.setBalance(balance);
		customer.setAccount(account);
		
		transactionList = customer.getTransactionList();
		Transaction transaction = new Transaction("Deposit", new Date(), 0, amount);
		transaction.setCustomer(customer);
		transactionList.add(transaction);
		customer.setTransactionList(transactionList);
		customerRepository.save(customer);
		return true;
	}

	public boolean withdraw(int customerId, double amount)  {
		
		customer = customerRepository.findById(customerId).get();
		if (customer.getAccount().getBalance() < amount) {
			return false;
		} else {
		
		double balance = customer.getAccount().getBalance() - amount;
		account = customer.getAccount();
		account.setBalance(balance);
		customer.setAccount(account);
		
		transactionList = customer.getTransactionList();
		Transaction transaction = new Transaction("withdraw", new Date(), 0, amount);
		transaction.setCustomer(customer);
		transactionList.add(transaction);
		customer.setTransactionList(transactionList);
		customerRepository.save(customer);
		return true;
		}
	}

	public boolean fundTransfer(int senderCustomerId, int receiverCustomerId,double amount) {
		System.out.println(senderCustomerId+" "+receiverCustomerId);
		Customer senderCustomer = customerRepository.findById(senderCustomerId).get();
		System.out.println("sender"+senderCustomer);
		Customer receiverCustomer = customerRepository.findById(receiverCustomerId).get();
		System.out.println("rece"+receiverCustomer);
		if (senderCustomer.getAccount().getBalance() < amount) {
			return false;
		} else {
			Account receiverAccount = receiverCustomer.getAccount();
			double receiverBalance = receiverAccount.getBalance();
			receiverBalance = receiverAccount.getBalance() + amount;
			receiverAccount.setBalance(receiverBalance);
			receiverCustomer.setAccount(receiverAccount);

			Account senderAccount = senderCustomer.getAccount();
			double senderBalance = senderAccount.getBalance();
			senderBalance = senderAccount.getBalance() - amount;
			senderAccount.setBalance(senderBalance);
			senderCustomer.setAccount(senderAccount);

			Transaction sendertransaction = new Transaction("Ft",  new Date(), receiverAccount.getAccountNo(),
					amount);
			sendertransaction.setCustomer(senderCustomer);
			List<Transaction> senderTransactionList = new ArrayList<Transaction>();
			senderTransactionList = senderCustomer.getTransactionList();
			senderTransactionList.add(sendertransaction);

			Transaction recievetransaction = new Transaction("Fr", new Date(), senderAccount.getAccountNo(),
					amount);
			recievetransaction.setCustomer(receiverCustomer);
			List<Transaction> recieveTransactionList = new ArrayList<Transaction>();
			recieveTransactionList = receiverCustomer.getTransactionList();
			recieveTransactionList.add(recievetransaction);

			senderCustomer.setTransactionList(senderTransactionList);
			receiverCustomer.setTransactionList(recieveTransactionList);

			customerRepository.save(receiverCustomer);
			customerRepository.save(senderCustomer);
			return true;
		}
	}

	public List<Transaction> printTransaction(int customerId) {
		
		return customerRepository.findById(customerId).get().getTransactionList();
	}

	@Override
	public Customer validateId(int customerId) {
		return customerRepository.validateId(customerId);
	}

}
