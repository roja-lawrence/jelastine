package com.cg.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;
import com.cg.Util.BankUtil;

public class BankDAOImpl implements BankDAO {
	public Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connect = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");

		return connect;
	}

	public void storeIntoAccountDatabase(Account account) throws Exception {
		Connection connect = getConnection();
		PreparedStatement statement1 = connect
				.prepareStatement("Delete from Account where accountNumber ='" + account.getAccountNumber() + "'");
		PreparedStatement statement = connect
				.prepareStatement("Insert into Account (accountNumber,name,mobileNumber,amount) values (?,?,?,?)");

		ResultSet results1 = statement1.executeQuery();
		statement.setInt(1, account.getAccountNumber());
		statement.setString(2, account.getName());
		statement.setString(3, account.getMobileNumber());
		statement.setDouble(4, account.getAmount());

		ResultSet results = statement.executeQuery();

		results1.close();
		results.close();

		statement.close();
		// connect.commit();
		connect.close();
	}

	public Account getFromAccountDatabase(int accountNumber) throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat.executeQuery("Select * from Account where accountNumber=' " + accountNumber + " ' ");

		String name = "";
		String mobile = "";
		double balance = 0;

		while (res.next()) {
			name = res.getString(2);
			mobile = res.getString(3);
			balance = res.getDouble(4);
		}
		Account account = new Account(accountNumber, name, mobile, balance);
		// connect.commit();
		return account;
	}

	public void storeIntoWalletDatabase(Wallet wallet) throws Exception {
		Connection connect = getConnection();
		PreparedStatement statement = connect
				.prepareStatement("Insert into Wallet (walletId,walletAmount) values (?,?)");
		PreparedStatement statement1 = connect
				.prepareStatement("Delete from Wallet where walletId ='" + wallet.getWalletID() + "'");
		statement.setInt(1, wallet.getWalletID());
		statement.setDouble(2, wallet.getWalletAmount());

		ResultSet results1 = statement1.executeQuery();
		ResultSet results = statement.executeQuery();

		results.close();
		results1.close();
		statement.close();
		connect.close();
	}

	public Wallet getFromWalletDatabase(int walletID) throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat.executeQuery("Select * from Wallet where walletId=' " + walletID + " ' ");

		double balance = 0;

		while (res.next()) {
			balance = res.getDouble(2);
		}
		Wallet wallet = new Wallet(walletID, balance);
		// connect.commit();
		return wallet;
	}

	public void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions) throws Exception {
		Connection connect = getConnection();
		PreparedStatement statement = connect
				.prepareStatement("Insert into transactionDatabase (accountNumber,transaction) values (?,?)");

		for (String transact : transactions.getTransactList()) {
			statement.setInt(1, accountNumber);
			statement.setString(2, transact);
		}

		ResultSet results = statement.executeQuery();

		results.close();
		statement.close();
		connect.close();
	}

	public Transactions getFromTransactionsDatabase(int accountNumber) throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat
				.executeQuery("Select * from transactionDatabase where accountNumber=' " + accountNumber + " ' ");
		Transactions transact = new Transactions();
		String transaction = "";

		while (res.next()) {
			transaction = res.getString(2);
			transact.addToTransactionList(transaction);
		}

		// connect.commit();

		return transact;
	}

	public void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions)
			throws Exception {
		Connection connect = getConnection();
		PreparedStatement statement = connect
				.prepareStatement("Insert into walletTransactionDatabase (walletId, walletTransaction) values (?,?)");

		for (String transact : walletTransactions.getTransactList()) {
			statement.setInt(1, walletID);
			statement.setString(2, transact);
		}

		ResultSet results = statement.executeQuery();

		results.close();
		statement.close();
		connect.close();
	}

	public WalletTransactions getFromWalletTransactionsDatabase(int walletID) throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat
				.executeQuery("Select * from walletTransactionDatabase where walletId=' " + walletID + " ' ");

		String transaction = "";
		WalletTransactions transact = new WalletTransactions();

		while (res.next()) {
			transaction = res.getString(2);
			transact.addToTransactionList(transaction);
		}

		/*
		 * WalletTransactions transact = new WalletTransactions();
		 * transact.addToTransactionList(transaction);
		 */

		// connect.commit();

		return transact;
	}

	public int getAccountCount() throws Exception {

		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat.executeQuery("select count(*) from account");

		int length = 0;

		while (res.next()) {
			length = res.getInt(1);
		}

		// connect.commit();

		return length;
	}

	// Print all data from map
	public void getTransactionFromWalletDatabase() throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat.executeQuery("Select * from walletTransactionDatabase");

		String transaction = "";
		// WalletTransactions transact = new WalletTransactions();

		while (res.next()) {
			transaction = res.getString(2);
			System.out.println(transaction);
		}

		// connect.commit();

	}

	// Print all data from map
	public void getTransactionFromAccountDatabase() throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = stat.executeQuery("Select * from transactionDatabase");

		String transaction = "";
		// Transactions transact = new Transactions();

		while (res.next()) {
			transaction = res.getString(2);
			System.out.println(transaction);
		}

		// connect.commit();
	}

	public void addToTransactionList(int id, String transaction) throws Exception {
		/*
		 * Connection connect = getConnection(); PreparedStatement statement = connect
		 * .prepareStatement("Insert into transactionDatabase (accountNumber,transaction) values (?,?)"
		 * );
		 * 
		 * statement.setInt(1, id); statement.setString(2, transaction);
		 * 
		 * ResultSet results = statement.executeQuery();
		 * 
		 * results.close(); statement.close(); connect.close();
		 */
		BankUtil.addToTransactionList(transaction);
	}

	public void addToWalletTransactionList(String transaction) {
		BankUtil.addToWalletTransactionList(transaction);
	}

	public boolean validateAccountCredentials(int userName, String passWord) throws Exception {
		Connection connect = getConnection();
		Statement stat = connect.createStatement();
		ResultSet res = null;

		if (userName <= getAccountCount())
			res = stat.executeQuery(
					"Select accountNumber,mobileNumber from Account where accountNumber=' " + userName + " ' ");
		else
			return false;

		int dbUsername = 0;
		String dbPassword = "";

		while (res.next()) {
			dbUsername = res.getInt(1);
			dbPassword = res.getString(2);
		}

		if (dbUsername == userName && dbPassword.equals(passWord))
			return true;
		else
			return false;

	}
}
