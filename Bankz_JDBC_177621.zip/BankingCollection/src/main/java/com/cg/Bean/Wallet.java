package com.cg.Bean;

public class Wallet {
	private int walletID;
	private double walletAmount;

	public Wallet() {
		this.walletID = 0;
		this.walletAmount = 0;
	}

	public Wallet(int walletID, double walletAmount) {
		this.walletID = walletID;
		this.walletAmount = walletAmount;
	}

	public int getWalletID() {
		return walletID;
	}

	public void setWalletID(int walletID) {
		this.walletID = walletID;
	}

	public double getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(double walletAmount) {
		this.walletAmount = walletAmount;
	}

	@Override
	public String toString() {
		return "" + "Wallet ID: " + walletID + "Wallet Money: " + walletAmount + "\n";
	}
}
