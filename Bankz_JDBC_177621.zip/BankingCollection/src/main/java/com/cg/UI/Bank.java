package com.cg.UI;

import java.io.FileWriter;
import java.io.Writer;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;
import com.cg.Service.BankService;
import com.cg.Service.BankServiceImpl;
import com.cg.Util.BankUtil;

public class Bank {
	static public int accountNumber;
	static public int walletID;
	static boolean bool;
	static double transferableAmount = 0;

	static Scanner input = new Scanner(System.in);
	static Account account = new Account();
	//static Wallet wallet = new Wallet();
	static BankService rockstarBankService = new BankServiceImpl();
	static BankUtil util = new BankUtil();
	static Transactions transact = new Transactions();
	static WalletTransactions walletTransact = new WalletTransactions();

	// Main menu
	public static void mainMenu() throws Exception {
		bool = true;

		while (bool) {
			System.out.println("\nEnter Your Choice:");
			System.out.println("\n0. Terminate App");
			System.out.println("1. Check Balance");
			System.out.println("2. Deposit Amount");
			System.out.println("3. Withdraw Amount");
			System.out.println("4. Fund Transfer");
			System.out.println("5. Transaction History");
			System.out.println("6. Account Details");
			System.out.println("7. Logout");

			System.out.print("\nYour Choice: ");
			switch (input.nextInt()) {
			case 0:
				bool = false;
				break;
			case 1:
				showBalance();
				break;
			case 2:
				depositAmount();
				break;
			case 3:
				withdrawAmount();
				break;
			case 4:
				fundTransfer();
				break;
			case 5:
				printTransaction();
				break;
			case 6:
				accountDetails();
				break;
			case 7:
				main(null);
				/* transact = null; walletTransact = null; */break;
			default:
				System.out.println("Invalid option");
				break;
			}
		}
	}

	// Create Account
	public static void createAccount() throws Exception {
		Account newAccount = new Account();
		Wallet newWallet = new Wallet();

		// Account Data
		//int getLastAccountNumber = 0;
		/*
		 * try { getLastAccountNumber = rockstarBankService1.getLastAccountNumber(); }
		 * catch (Exception e) { e.getMessage(); }
		 */

		/*System.out.println(getLastAccountNumber);
		newAccount.setAccountNumber(++getLastAccountNumber);*/
		newAccount.setAccountNumber(++accountNumber + 5);

		System.out.print("Enter Your Name:");
		newAccount.setName(input.next());
		System.out.println();

		System.out.print("Enter Your Mobile Number:");
		newAccount.setMobileNumber(input.next());
		System.out.println();

		System.out.print("Enter Initial Deposit Amount:");
		newAccount.setAmount(input.nextInt());
		creditAccount(newAccount.getAmount());
		System.out.println();

		// Store Account Data into rockstarBankService
		rockstarBankService.storeIntoAccountDatabase(newAccount);
		/*
		 * try { rockstarBankService1.storeIntoAccountDatabase(newAccount); }
		 * catch(Exception e) { System.out.println(e); }
		 */
		// rockstarBankService.storeIntoTransactionsDatabase(newAccount.getAccountNumber(),
		// transact);

		// Wallet Data
		newWallet.setWalletID(++walletID + 5);
		newWallet.setWalletAmount(0);

		// Store Wallet Data into rockstarBankService
		rockstarBankService.storeIntoWalletDatabase(newWallet);

		// Initial Transaction
		transact.addToTransactionList(newAccount.getAmount() + "cr -> \t" + newAccount.getAmount());
		rockstarBankService.storeIntoTransactionsDatabase(newAccount.getAccountNumber(), transact);

		// Display Account Info
		System.out.println("Account Created Succesfully");
		System.out.println("\nYour Account Number(UserName): " + "RB000" + newAccount.getAccountNumber());
		System.out.println("Your Mobile Number(Password): " + newAccount.getMobileNumber());
		System.out.println("Your Wallet Id " + "WM000" + newWallet.getWalletID());
		System.out.println("\nYou will recieve a OTP in file when logging in.");
	}

	// Shows Balance in Account & Wallet
	public static void showBalance() throws Exception {
		bool = true;

		while (bool) {
			System.out.println("\nEnter your choice:");
			System.out.println("\n0.Back");
			System.out.println("1.Account");
			System.out.println("2.Wallet");

			System.out.print("\nYour Choice: ");
			switch (input.nextInt()) {
			case 0:
				bool = false;
				mainMenu();
				break;
			case 1:
				System.out.println("\nYour Account Balance: " + account.getAmount());
				break;
			case 2:
				System.out.println("\nYour Wallet Balance: " + account.getWallet().getWalletAmount());
				break;
			default:
				System.out.println("Invalid option");
				showBalance();
				break;
			}
		}
	}

	// Credit in Account
	public static void depositAmount() throws Exception {
		System.out.print("\nEnter the amount yout want to deposit: ");
		transferableAmount = input.nextInt();
		creditAccount(transferableAmount);
		getAccountBalance.accept("");

	}

	// Debit from Account
	public static void withdrawAmount() throws Exception {
		System.out.print("\nEnter the amount yout want to withdraw: ");
		transferableAmount = input.nextInt();
		debitAccount(transferableAmount);
		getAccountBalance.accept("");
	}

	// Tranfer funds
	public static void fundTransfer() throws Exception {
		bool = true;

		while (bool) {

			System.out.println("\nEnter your choice");
			System.out.println("\n0.Back");
			System.out.println("1. Bank to Wallet");
			System.out.println("2. Wallet to Bank");
			System.out.println("3. Bank to Bank");
			System.out.println("4. Wallet to Wallet");
			System.out.println("5. Bank to Another Wallet");

			try {
				System.out.print("\nYour Choice: ");
				switch (input.nextInt()) {
				case 0: {
					bool = false;
					mainMenu();
					break;
				}

				// Transfer from Bank to Wallet
				case 1: {
					System.out.print("\nEnter the amount to be transfered to wallet: ");
					transferableAmount = input.nextInt();

					debitAccount(transferableAmount);
					creditWallet(transferableAmount);

					getAccountBalance.accept("");
					getWalletBalance.accept("");
				}
					break;

				// Transfer from Wallet to Bank
				case 2: {
					System.out.print("\nEnter the amount to be transfered to Bank: ");
					transferableAmount = input.nextInt();

					debitWallet(transferableAmount);
					creditAccount(transferableAmount);

					getAccountBalance.accept("");
					getWalletBalance.accept("");
				}
					break;

				// Transfer from Bank to Another bank
				case 3: {

					System.out.print("\nEnter account number to which you want to transfer the amount: RB000");
					int accountNumber = input.nextInt();

					if (rockstarBankService.getAccountCount() >= accountNumber) {
						Account anotherAccount = rockstarBankService.getFromAccountDatabase(accountNumber);

						System.out.print("\nEnter the amount to be transfered to Another Account: ");
						transferableAmount = input.nextInt();

						debitAccount(transferableAmount);
						creditAccount(transferableAmount, anotherAccount);

						getAccountBalance.accept("");
					}
				}
					break;

				// Transfer from Wallet to Another Wallet
				case 4: {
					System.out.print("\nEnter wallet ID to which you want to transfer the amount: WM000");
					int walletID = input.nextInt();

					if (validateAccountNumber(walletID)) {
						Wallet anotherWallet = rockstarBankService.getFromWalletDatabase(walletID);

						System.out.print("\nEnter the amount to be transfered to Another Wallet: ");
						transferableAmount = input.nextInt();

						debitWallet(transferableAmount);
						creditWallet(transferableAmount, anotherWallet);

						getWalletBalance.accept("");
					}
				}
					break;

				// Transfer from Bank to Another Wallet
				case 5: {
					System.out.print("\nEnter wallet ID to which you want to transfer the amount: WM000");
					int walletID = input.nextInt();

					if (validateAccountNumber(walletID)) {
						Wallet anotherWallet = rockstarBankService.getFromWalletDatabase(walletID);

						System.out.print("\nEnter the amount to be transfered to Another Wallet: ");
						transferableAmount = input.nextInt();

						debitAccount(transferableAmount);
						creditWallet(transferableAmount, anotherWallet);

						getAccountBalance.accept("");
					}
				}
					break;

				default: {
					System.out.println("\nInvalid option");
					fundTransfer();
					break;
				}
				}

			}

			catch (Exception e) {
				System.out.println("\nInvalid Operation");
				System.out.println(e);
				bool = false;
			}

			finally {
				if (!bool)
					mainMenu();
			}
		}
	}

	// Get Transaction History
	public static void printTransaction() throws Exception {
		Transactions transaction = rockstarBankService.getFromTransactionsDatabase(account.getAccountNumber());
		WalletTransactions walletTransaction = rockstarBankService
				.getFromWalletTransactionsDatabase(account.getWallet().getWalletID());

		bool = true;

		while (bool) {
			System.out.println("\nEnter your choice: ");
			System.out.println("\n0.Back");
			System.out.println("1.Account");
			System.out.println("2.Wallet");

			System.out.print("Your Choice: ");
			switch (input.nextInt()) {
			case 0: {
				bool = false;
				mainMenu();
				break;
			}

			case 1: {
				if (transaction != null) {
					System.out.println("\nTransaction History:");
					System.out.println("Cr./Dr. \tBalance");
					for (String transactions : transaction.getTransactList())
						System.out.println(transactions);
				}

				else
					System.out.println("\nNo Transactions Yet!");
				// rockstarBankService.getTransactionFromAccountDatabase();
			}
				break;

			case 2: {
				if (walletTransaction != null) {
					System.out.println("\nTransaction History:");
					System.out.println("Cr./Dr. \tBalance");
					for (String walletTransactions : walletTransaction.getTransactList())
						System.out.println(walletTransactions);
					// rockstarBankService.getDataFromMap();
				}

				else
					System.out.println("\nNo Transactions Yet!");
				// rockstarBankService.getTransactionFromWalletDatabase();

			}
				break;

			default:
				System.out.println("Invalid option");
			}
		}

	}

	public static void accountDetails() {
		System.out.println(account);
	}

	/*
	 * ---------------------------------------- Supporting Methods----------
	 * ------------------------------
	 */

	// User Interface
	public static void main(String[] args) throws Exception {
		bool = true;

		while (bool) {
			System.out.println("\n---------Welcome To Rockstar Bank---------");
			System.out.println("\nEnter Your Choice: ");
			System.out.println("\n0. Terminate App");
			System.out.println("1. Login");
			System.out.println("2. Create Account.");

			System.out.print("\nYour Choice: ");
			switch (input.nextInt()) {
			case 0: {
				bool = false;
				break;
			}
			case 1: {
				validateAccount();
				bool = false;
				break;
			}
			case 2: {
				createAccount();
				break;
			}
			default: {
				System.out.println("\nInvalid option");
				break;
			}
			}
		}
	}

	// Generate OTP using Random
	static Supplier<Integer> OTP = () -> {
		Random random = new Random();
		return random.nextInt((9998 - 1001) + 1) + 1001;
	};

	static Consumer<String> getAccountBalance = balance -> System.out
			.println("\nUpdated Account Balance: " + account.getAmount());
	static Consumer<String> getWalletBalance = balance -> System.out
			.println("\nUpdated Wallet Balance: " + account.getWallet().getWalletAmount());

	// Validate User Credentials
	public static void validateAccount() throws Exception {
		bool = true;

		while (bool) {
			System.out.print("\nEnter UserName (Account Number): RB000");
			int userName = input.nextInt();

			System.out.print("Enter PassWord (Mobile Number): ");
			String passWord = input.next();

			// Get OTP
			Integer oneTimePassword = getOTP();

			// Write OTP to File
			try {
				Writer generateOTP = new FileWriter("OTP.txt");
				generateOTP.write(oneTimePassword.toString());
				generateOTP.close();
			}

			catch (Exception e) {
				System.out.println("Oops!, Something went wrong!");
			}
			
			// Validates UserName, Password & OTP
			if (rockstarBankService.checkCredentials(userName, passWord)) {
				System.out.print("\nEnter OTP: ");
				int userOTP = input.nextInt();

				if (oneTimePassword == userOTP) {
					account = rockstarBankService.getFromAccountDatabase(userName);

					if (account.getWallet().getWalletID() == 0)
						account.getWallet().setWalletID(account.getAccountNumber());

					// Get Initial Deposit Transaction
					if (transact.getTransactList().isEmpty()
							&& account.getAccountNumber() <= rockstarBankService.getAccountCount()) {
						transact.addToTransactionList(account.getAmount() + "cr -> \t" + account.getAmount());
						rockstarBankService.storeIntoTransactionsDatabase(account.getAccountNumber(), transact);
					}

					mainMenu();
					bool = false;
				}

				else
					System.out.println("\nInvalid OTP");
			} else
				System.out.println("\nWrong Credentials..! Try Again.");
		}
	}

	private static boolean validateAccountNumber(int accountNumber) throws Exception {
		if (account.getAccountNumber() > 0 && accountNumber <= rockstarBankService.getAccountCount()) {
			return true;
		} else {
			System.out.println("\nAccount doesn't exist!, Try again.");
			fundTransfer();
			return false;
		}
	}

	private static void creditAccount(double transferableAmount) throws Exception {
		account.setAmount(account.getAmount() + transferableAmount);

		transact.addToTransactionList(transferableAmount + "cr -> \t" + account.getAmount());
		rockstarBankService.storeIntoTransactionsDatabase(account.getAccountNumber(), transact);
		rockstarBankService.storeIntoAccountDatabase(account);
	}

	private static void creditAccount(double transferableAmount, Account anotherAccount) throws Exception {
		anotherAccount.setAmount(anotherAccount.getAmount() + transferableAmount);

		if (rockstarBankService.getFromTransactionsDatabase(anotherAccount.getAccountNumber()) == null) {
			Transactions anotherTransact = new Transactions();

			anotherTransact.addToTransactionList(transferableAmount + "cr -> \t" + anotherAccount.getAmount());
			rockstarBankService.storeIntoTransactionsDatabase(anotherAccount.getAccountNumber(), anotherTransact);
		} else {
			Transactions anotherTransact = rockstarBankService
					.getFromTransactionsDatabase(anotherAccount.getAccountNumber());
			List<String> existingList = anotherTransact.getTransactList();

			existingList.add(transferableAmount + "cr -> \t" + anotherAccount.getAmount());
			anotherTransact.setTransactList(existingList);
			rockstarBankService.storeIntoTransactionsDatabase(anotherAccount.getAccountNumber(), anotherTransact);
		}
		rockstarBankService.storeIntoAccountDatabase(anotherAccount);
	}

	private static void debitWallet(double transferableAmount) throws Exception {
		if (account.getWallet().getWalletAmount() >= transferableAmount) {
			account.getWallet().setWalletAmount(account.getWallet().getWalletAmount() - transferableAmount);
			walletTransact
					.addToTransactionList(transferableAmount + "dr -> \t" + account.getWallet().getWalletAmount());
			rockstarBankService.storeIntoWalletTransactionsDatabase(account.getWallet().getWalletID(), walletTransact);
		}

		else
			System.out.println("Insufficient Balance");
		rockstarBankService.storeIntoWalletDatabase(account.getWallet());
	}

	private static void creditWallet(double transferableAmount, Wallet anotherWallet) throws Exception {
		anotherWallet.setWalletAmount(anotherWallet.getWalletAmount() + transferableAmount);

		if (rockstarBankService.getFromWalletTransactionsDatabase(anotherWallet.getWalletID()) == null) {
			WalletTransactions anotherWalletTransact = new WalletTransactions();
			anotherWalletTransact
					.addToTransactionList(transferableAmount + "cr -> \t" + anotherWallet.getWalletAmount());
			rockstarBankService.storeIntoWalletTransactionsDatabase(anotherWallet.getWalletID(), anotherWalletTransact);
		} else {
			WalletTransactions anotherWalletTransact = rockstarBankService
					.getFromWalletTransactionsDatabase(anotherWallet.getWalletID());
			List<String> existingList = anotherWalletTransact.getTransactList();
			existingList.add(transferableAmount + "cr -> \t" + anotherWallet.getWalletAmount());
			anotherWalletTransact.setTransactList(existingList);
			rockstarBankService.storeIntoWalletTransactionsDatabase(anotherWallet.getWalletID(), anotherWalletTransact);
		}
		rockstarBankService.storeIntoWalletDatabase(anotherWallet);
	}

	private static void creditWallet(double transferableAmount) throws Exception {
		account.getWallet().setWalletAmount(account.getWallet().getWalletAmount() + transferableAmount);

		walletTransact.addToTransactionList(transferableAmount + "cr -> \t" + account.getWallet().getWalletAmount());
		rockstarBankService.storeIntoWalletTransactionsDatabase(account.getWallet().getWalletID(), walletTransact);
		rockstarBankService.storeIntoAccountDatabase(account);
		rockstarBankService.storeIntoWalletDatabase(account.getWallet());
	}

	private static void debitAccount(double transferableAmount) throws Exception {
		if (account.getAmount() >= transferableAmount) {
			account.setAmount(account.getAmount() - transferableAmount);

			transact.addToTransactionList(transferableAmount + "dr -> \t" + account.getAmount());
			rockstarBankService.storeIntoTransactionsDatabase(account.getAccountNumber(), transact);
		} else
			System.out.println("Insufficient Balance");
		rockstarBankService.storeIntoAccountDatabase(account);
	}

	public static int getOTP() {
		Random random = new Random();
		return random.nextInt((9998 - 1001) + 1) + 1001;
	}

}
