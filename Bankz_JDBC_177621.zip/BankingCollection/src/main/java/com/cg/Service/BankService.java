package com.cg.Service;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;

public interface BankService {
	public void storeIntoAccountDatabase(Account account) throws Exception;

	public Account getFromAccountDatabase(int accountNumber) throws Exception;

	public void storeIntoWalletDatabase(Wallet wallet) throws Exception;

	public Wallet getFromWalletDatabase(int walletID) throws Exception;

	public void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions) throws Exception;

	public Transactions getFromTransactionsDatabase(int accountNumber) throws Exception;

	public void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions) throws Exception;

	public WalletTransactions getFromWalletTransactionsDatabase(int walletID) throws Exception;

	public int getAccountCount() throws Exception;

	public void getTransactionFromWalletDatabase() throws Exception;

	public void getTransactionFromAccountDatabase() throws Exception;

	public boolean checkCredentials(int userName, String passWord) throws Exception;
}
