package com.cg.Service;

import com.cg.Bean.Account;
import com.cg.Bean.Transactions;
import com.cg.Bean.Wallet;
import com.cg.Bean.WalletTransactions;
import com.cg.DAO.BankDAOImpl;
import com.cg.Util.BankUtil;

public class BankServiceImpl implements BankService {
	BankDAOImpl db = new BankDAOImpl();

	public void storeIntoAccountDatabase(Account account) throws Exception {
		db.storeIntoAccountDatabase(account);
	}

	public Account getFromAccountDatabase(int accountNumber) throws Exception {
		return db.getFromAccountDatabase(accountNumber);
	}

	public void storeIntoWalletDatabase(Wallet wallet) throws Exception {
		db.storeIntoWalletDatabase(wallet);
	}

	public Wallet getFromWalletDatabase(int walletID) throws Exception {
		return db.getFromWalletDatabase(walletID);
	}

	public void storeIntoTransactionsDatabase(int accountNumber, Transactions transactions) throws Exception {
		db.storeIntoTransactionsDatabase(accountNumber, transactions);
	}

	public Transactions getFromTransactionsDatabase(int accountNumber) throws Exception {
		return db.getFromTransactionsDatabase(accountNumber);
	}

	public void storeIntoWalletTransactionsDatabase(int walletID, WalletTransactions walletTransactions) throws Exception {
		db.storeIntoWalletTransactionsDatabase(walletID, walletTransactions);
	}

	public WalletTransactions getFromWalletTransactionsDatabase(int walletID) throws Exception {
		return db.getFromWalletTransactionsDatabase(walletID);
	}

	public int getAccountCount() throws Exception {
		return db.getAccountCount();
	}

	// Print all data from map
	public void getTransactionFromWalletDatabase() throws Exception {
		db.getTransactionFromWalletDatabase();
	}

	// Print all data from map
	public void getTransactionFromAccountDatabase() throws Exception {
		db.getTransactionFromAccountDatabase();
	}

	public void addToTransactionList(int id, String transaction) throws Exception {
		db.addToTransactionList(id, transaction);
	}

	public void addToWalletTransactionList(String transaction) {
		db.addToWalletTransactionList(transaction);
	}

	public boolean checkCredentials(int userName, String passWord) throws Exception {
		return db.validateAccountCredentials(userName, passWord);
	}
}
